
## Example of replication paper

https://www.tandfonline.com/doi/full/10.1080/17421772.2022.2123111

https://www.overleaf.com/read/rxsphdrkpytw#3b16f0

